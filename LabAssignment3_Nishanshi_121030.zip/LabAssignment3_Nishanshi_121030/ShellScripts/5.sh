z="y"
while [ " $z " = " y " ]
do
	echo "enter numbers (below 50)"
	read x
	if [ " $x " -le 50 ] ; then
	{
		n=` expr $x \* $x `
		echo " square of $x is $n ";
	}
	else
	{
		echo "number not below 50";
	}
	fi
	echo "do you want to continue? (y/n)"
	read a	
	if [ " $a " = " n " ] ; then
		z="n" ;
	fi
done
