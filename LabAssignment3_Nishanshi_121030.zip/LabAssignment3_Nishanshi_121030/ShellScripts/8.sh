a1=1
echo $a1
a2=1
echo $a2
for((i=0;i<10;i++))
do
	a3=` expr $a1 + $a2 `
	echo $a3
	a1=$a2
	a2=$a3
done	
