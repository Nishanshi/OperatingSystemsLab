echo "x: "
read x
echo "y: "
read y
if [ " $x " -gt " $y " ] ; then
{
	echo " x i.e. $x is greater";
}
elif [ " $y " -gt " $x " ] ; then
{
	echo " y i.e. $y is greater";
}
else
{
	echo "both equal";
}
fi
