echo "x: "
read x
echo "y: "
read y
n1=` expr $x + $y `
n2=` expr $x - $y `
n3=` expr $x \* $y `
n4=` expr $x \/ $y `
n5=` expr $x \% $y `
echo "addition: $n1 subtraction: $n2 multiplication: $n3 division: $n4 remainder: $n5"
