echo "enter text: "
read x
case "$x" in
	jan ) echo " january " ;;
	janu ) echo " january " ;;
	janua ) echo " january " ;;
	januar ) echo " january " ;;
	january ) echo " january " ;;
	*) echo "text not related to january" ;;
esac 
