x=1
while [ " $x " -eq 1 ]
do
	echo "what is capital of gujarat? (answer in lowercase)"
	read ans
	if [ " $ans " = " gandhinagar " ] ; then
	{
		x=0
		echo "correct";
	}
	fi
done
