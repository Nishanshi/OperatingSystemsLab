echo "write command"
read c
exec $c
