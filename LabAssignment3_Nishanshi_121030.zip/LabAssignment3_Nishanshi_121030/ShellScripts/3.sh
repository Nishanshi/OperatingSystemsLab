echo "x: "
read x
echo "y: "
read y
echo "expression: "
read z
if [ " $z " = " + " ] ; then
{
	n=` expr $x + $y `
	echo $n;
}
elif [ " $z " = " - " ] ; then
{
	n=` expr $x - $y `
	echo $n;
}
elif [ " $z " = " * " ] ; then
{
	n=` expr $x \* $y `
	echo $n;
}
elif [ " $z " = " / " ] ; then
{
	n=` expr $x \/ $y `
	echo $n;
}
elif [ " $z " = " % " ] ; then
{
	n=` expr $x \% $y `
	echo $n;
}
fi
