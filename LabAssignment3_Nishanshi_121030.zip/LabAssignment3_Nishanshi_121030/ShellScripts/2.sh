x=99
y=11
echo "x is 99 and y is 11, expression to be performed on them: "
read z
if [ " $z " = " + " ] ; then
{
	n=` expr $x + $y `
	echo $n;
}
elif [ " $z " = " - " ] ; then
{
	n=` expr $x - $y `
	echo $n;
}
elif [ " $z " = " * " ] ; then
{
	n=` expr $x \* $y `
	echo $n;
}
elif [ " $z " = " / " ] ; then
{
	n=` expr $x \/ $y `
	echo $n;
}
elif [ " $z " = " % " ] ; then
{
	n=` expr $x \% $y `
	echo $n;
}
fi
