echo "length of list: "
read n
echo ${num[n]}
echo "list of numbers: "
for((i=0;i<n;i++))
do
	read num[$i]
done
i=0
c=0
frst_occr=0
echo "element to be searched: "
read a
while [ " $c " -eq 0 -a " $i " -lt " $n " ]
do
	if [ " $a " -eq ${num[$i]} ] ; then
		frst_occr=$i
		c=1;
	fi
	i=` expr $i + 1 `
done
if [ " $c " -eq 1 ] ; then
	echo "in list at index number $frst_occr in list";
else
	echo "not in list";
fi
