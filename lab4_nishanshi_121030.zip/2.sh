echo "enter a sting"
read x
y=$(grep -c "$x" t2.txt)
if [ " $y " -gt 0 ];
then
	echo "string present in t2.txt";
else
	echo "string not present in t2.txt";
fi
 
