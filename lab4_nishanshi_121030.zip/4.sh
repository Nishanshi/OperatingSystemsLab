echo "enter number"
read n
y=$(factor $n)
if [ " $y " = " $n: $n " ] ;
then
	echo "prime";
else
	echo "not prime";
fi
