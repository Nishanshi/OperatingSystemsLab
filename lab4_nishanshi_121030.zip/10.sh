exec wc -w t2.txt
