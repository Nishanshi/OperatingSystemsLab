y=1
while [ " $y " -eq 1 ]
do
	a=1
	echo "enter a number (below 50)"
	read x
	if [ " $x " -le 50 ];
	then
		z=` expr $x \* $x `
		echo $z;
	else
		echo " invalid input ";
	fi

	while [ " $a " -eq 1 ]
	do
		echo "do you want to continue (y/n)"
		read b
		if [ " $b " = " n " ];
		then
			y=0
			a=0;
		elif [ " $b " != " y " -a " $b " != " n " ];
		then
			echo "invalid input";
		else 
			a=0;
		fi
	done
done
	
	
