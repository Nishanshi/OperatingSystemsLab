n=10
a=` expr $n + 1 `
b=` expr $n \* $a `
c=` expr $b \/ 2 `
echo $c 
