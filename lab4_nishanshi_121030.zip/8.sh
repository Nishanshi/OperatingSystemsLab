exec wc -l t2.txt
