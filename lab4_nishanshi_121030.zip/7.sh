echo " enter filename "
read filename
echo " Do you want to revoke the read, write permissions for the group and others for this file? (y/n) "
read ans
if [ " $ans " = " y " ];
then
	exec chmod 777 $filename;
fi
