exec fgrep -o ' ' t2.txt | wc -l
