echo "enter salary: "
read x
echo "enter % HRA: "
read y
a=` expr $x \* $y `
b=` expr $a \/ 100 `
echo "if HRA is $x %, its value is $b"
